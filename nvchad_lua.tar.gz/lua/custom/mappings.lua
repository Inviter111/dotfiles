---@type MappingsTable
local M = {}

M.general = {
  n = {
    [";"] = { ":", "enter command mode", opts = { nowait = true } },
  },
}

M.coc = {
  i = {
    ["<CR>"] = { "pumvisible() ? coc#_select_confirm() : \"<C-g>u<TAB>\"", "Select suggestion", opts = { noremap = true, silent = true, expr = true } },
  }
}

-- more keybinds!

return M
