const itemById = Array.from(
  new Set()
).reduce((byId, item) => {
  byId[item.id] = item
  return result;
}, {})
