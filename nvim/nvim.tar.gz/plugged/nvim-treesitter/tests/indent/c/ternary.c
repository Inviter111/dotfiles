void foo(int x)
{
    int y = (x > 10) ? 10
        : (x < -10) ? -10
        : x;
}
