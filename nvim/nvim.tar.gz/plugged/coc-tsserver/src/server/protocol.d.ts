import * as Proto from 'typescript/lib/protocol';
export = Proto;
